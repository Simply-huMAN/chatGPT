const Message = ({ chatMessage, index }) => {
  return (
    <>
      {!index % 2 && (
        <li
          key={index}
          className="min-w-full self-start bg-blue-400 p-2 rounded-md my-1"
        >
          <p className="role">{chatMessage.role}</p>
          <p>{chatMessage.content}</p>
        </li>
      )}
      {index % 2 && (
        <li key={index} className="min-w-full bg-blue-400 p-2 rounded-md my-1">
          <p className="role">{chatMessage.role}</p>
          <p>{chatMessage.content}</p>
        </li>
      )}
    </>
  );
};
export default Message;
