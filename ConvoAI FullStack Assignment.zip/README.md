# Convo AI Chat

> I made this project using React and Tailwind.
> Since this is a single page project, I made only two components of App.js and server.js

### Installation

> Download the zip file of my project
> Extract all the files from that downloaded folder
> Now install all the dependencies using the node package manager
> Just type "npm install" to install all the dependencies
> Now run the frontend page by typing "npm run start:frontend" in terminal
> Now open a new terminal, go to convoai/src folder
> Run "npm run start:backend" or "node server.js" to run the server
> Now you are good to go.
